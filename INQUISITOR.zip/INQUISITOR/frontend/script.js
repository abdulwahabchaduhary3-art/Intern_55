const internshipForm = document.getElementById("internshipForm");

if (internshipForm) {
    internshipForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const formData = new FormData(internshipForm);

        const internship = {
            title: formData.get("title"),
            company: formData.get("company"),
            description: formData.get("description"),
            requirements: formData.get("requirements"),
            duration: formData.get("duration"),
            deadline: formData.get("deadline"),
            status: formData.get("status")
        };

        console.log("Internship data:", internship);

        try {
            const response = await fetch("http://localhost:5000/api/internships", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(internship)
            });

            const data = await response.json();

            console.log("Backend response:", data);

            if (response.ok) {
                alert("Internship created successfully!");
                internshipForm.reset();
            } else {
                alert(data.message || "Something went wrong.");
            }

        } catch (error) {
            console.error("Error:", error);
            alert("Could not connect to the backend.");
        }
    });
}


function cancelForm() {
    const confirmation = confirm(
        "Are you sure you want to cancel?"
    );

    if (confirmation) {
        internshipForm.reset();
    }
}