const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());


// =====================================================
// TEST ROUTE
// =====================================================

app.get("/", (req, res) => {
    res.json({
        message: "INQUISITOR Backend API is running successfully!"
    });
});


// =====================================================
// INTERNSHIPS
// =====================================================

let internships = [];


// CREATE INTERNSHIP
app.post("/api/internships", (req, res) => {

    console.log("Internship received:", req.body);

    const {
        title,
        company,
        description,
        requirements,
        duration,
        deadline,
        status
    } = req.body;

    if (
        !title ||
        !company ||
        !description ||
        !requirements ||
        !duration ||
        !deadline
    ) {
        return res.status(400).json({
            message: "Please fill in all required fields."
        });
    }

    const newInternship = {
        id: internships.length + 1,
        title,
        company,
        description,
        requirements,
        duration,
        deadline,
        status: status || "Active"
    };

    internships.push(newInternship);

    console.log("Internship saved:", newInternship);

    res.status(201).json({
        message: "Internship created successfully!",
        internship: newInternship
    });
});


// GET ALL INTERNSHIPS
app.get("/api/internships", (req, res) => {

    res.json({
        internships: internships
    });

});


// =====================================================
// EVENTS
// =====================================================

// Temporary event storage
// Database abhi use nahi kar rahe.
// Server restart hone par data clear ho jayega.

let events = [];


// CREATE EVENT
app.post("/api/events", (req, res) => {

    console.log("Event received:", req.body);

    const {
        title,
        description,
        date,
        venue,
        capacity
    } = req.body;


    // Validation
    if (
        !title ||
        !description ||
        !date ||
        !venue ||
        !capacity
    ) {

        return res.status(400).json({
            message: "Please fill in all required fields."
        });

    }


    // Create new event
    const newEvent = {

        id: events.length + 1,

        title: title.trim(),

        description: description.trim(),

        date: date,

        venue: venue.trim(),

        capacity: Number(capacity)

    };


    // Save event
    events.push(newEvent);


    console.log("Event saved successfully:", newEvent);


    // Send response
    res.status(201).json({

        message: "Event created successfully!",

        event: newEvent

    });

});


// GET ALL EVENTS
app.get("/api/events", (req, res) => {

    console.log("Events requested");

    res.json({

        events: events

    });

});


// =====================================================
// EVENT ATTENDANCE
// =====================================================

let attendanceRecords = [];


// SAVE ATTENDANCE
app.post("/api/attendance", (req, res) => {

    console.log("Attendance received:", req.body);

    const {
        eventId,
        eventTitle,
        students
    } = req.body;


    if (
        !eventId ||
        !eventTitle ||
        !Array.isArray(students)
    ) {
        return res.status(400).json({
            message: "Invalid attendance data."
        });
    }


    const attendance = {
        id: attendanceRecords.length + 1,
        eventId: eventId,
        eventTitle: eventTitle,
        students: students,
        savedAt: new Date().toISOString()
    };


    attendanceRecords.push(attendance);


    console.log("Attendance saved:", attendance);


    res.status(201).json({
        message: "Attendance saved successfully!",
        attendance: attendance
    });

});


// GET ATTENDANCE
app.get("/api/attendance", (req, res) => {

    console.log("Attendance requested");

    res.json({
        attendance: attendanceRecords
    });

});

// =====================================================
// TEACHER APPLICATIONS
// =====================================================

let applications = [

    {
        id: 1,
        name: "Ali Khan",
        email: "ali@example.com",
        internship: "Frontend Web Development Intern",
        applied: "2026-08-10",
        status: "Pending",
        feedback: ""
    },

    {
        id: 2,
        name: "Sara Ahmed",
        email: "sara@example.com",
        internship: "Frontend Web Development Intern",
        applied: "2026-08-11",
        status: "Pending",
        feedback: ""
    },

    {
        id: 3,
        name: "Hamza Malik",
        email: "hamza@example.com",
        internship: "Frontend Web Development Intern",
        applied: "2026-08-12",
        status: "Pending",
        feedback: ""
    }

];


// GET ALL APPLICATIONS
app.get("/api/applications", (req, res) => {

    console.log("Applications requested");

    res.json({

        applications: applications

    });

});


// =====================================================
// SELECT / REJECT APPLICATION
// =====================================================

app.patch("/api/applications/:id/status", (req, res) => {

    const id = Number(req.params.id);

    const { status } = req.body;


    const application = applications.find(
        app => app.id === id
    );


    if (!application) {

        return res.status(404).json({
            message: "Application not found."
        });

    }


    if (
        status !== "Selected" &&
        status !== "Rejected" &&
        status !== "Pending"
    ) {

        return res.status(400).json({
            message: "Invalid application status."
        });

    }


    application.status = status;


    console.log(
        `Application ${id} status changed to ${status}`
    );


    res.json({

        message: "Application status updated successfully.",

        application: application

    });

});


// =====================================================
// SEND FEEDBACK
// =====================================================

app.post("/api/applications/:id/feedback", (req, res) => {

    const id = Number(req.params.id);

    const { feedback } = req.body;


    const application = applications.find(
        app => app.id === id
    );


    if (!application) {

        return res.status(404).json({
            message: "Application not found."
        });

    }


    if (!feedback || !feedback.trim()) {

        return res.status(400).json({
            message: "Please enter feedback."
        });

    }


    application.feedback = feedback.trim();


    console.log(
        `Feedback received for application ${id}:`,
        application.feedback
    );


    res.json({

        message: "Feedback uploaded successfully!",

        application: application

    });

});


// =====================================================
// START SERVER
// =====================================================

app.listen(PORT, () => {

    console.log(
        `Server running on http://localhost:${PORT}`
    );

});