const menu = document.querySelector(".menu-btn");

const nav = document.querySelector(".nav-links");

menu.addEventListener("click", () => {

    nav.classList.toggle("active");

});

const counters = document.querySelectorAll(".counter");

counters.forEach(counter => {

    const update = () => {

        const target = +counter.getAttribute("data-target");

        const count = +counter.innerText;

        const speed = 100;

        const increment = target / speed;

        if (count < target) {

            counter.innerText = Math.ceil(count + increment);

            setTimeout(update, 20);

        }
        else {

            counter.innerText = target;

        }

    }

    update();

});
/* Testimonial Slider */

let slides = document.querySelectorAll(".slide");

let current = 0;

setInterval(() => {

    slides[current].classList.remove("active");

    current = (current + 1) % slides.length;

    slides[current].classList.add("active");

}, 3000);

/* FAQ */

document.querySelectorAll(".faq-question").forEach(button => {

    button.onclick = () => {

        const answer = button.nextElementSibling;

        answer.style.display = answer.style.display === "block" ? "none" : "block";

    }

});

/* Back To Top */

const topBtn = document.getElementById("topBtn");

window.onscroll = function () {

    if (document.documentElement.scrollTop > 300) {

        topBtn.style.display = "block";

    } else {

        topBtn.style.display = "none";

    }

}

topBtn.onclick = function () {

    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

}

/* Dark Mode */

document.getElementById("themeBtn").onclick = function () {

    document.body.classList.toggle("dark");

}
// contact page
const form=document.getElementById("contactForm");

if(form){

form.addEventListener("submit",function(e){

e.preventDefault();

let name=document.getElementById("name").value.trim();

let email=document.getElementById("email").value.trim();

let subject=document.getElementById("subject").value.trim();

let message=document.getElementById("message").value.trim();

if(name==="" || email==="" || subject==="" || message===""){

alert("Please fill all fields.");

return;

}

alert("Message Sent Successfully!");

form.reset();

});

}